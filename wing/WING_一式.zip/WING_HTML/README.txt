WING｜歯科衛生士2.0

index.html            LP（公開用）
season01.html         SEASON 01 年間スケジュール（公開用）
plan-internal.html    事業設計書（社内用・公開しないこと）
wing-hero.jpg         LPのヒーロー写真

4つを同じフォルダに置いたまま index.html をダブルクリックすれば開きます。
Webフォントの読み込みにインターネット接続が必要です。
